#!/bin/bash

echo "[*] Обновление файлов проекта Aetherion..."

# Копируем каждый обновлённый файл в папку aetherion, заменяя старый
cp -v updated/aetherion/*.py aetherion/

echo "[*] Файлы успешно обновлены."
