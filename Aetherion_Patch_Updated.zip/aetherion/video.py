import os
import torch
from moviepy.editor import ImageSequenceClip
from PIL import Image
import glob

class VideoModule:
    def __init__(self, output_dir="output/video_frames", video_path="output/generated_video.mp4"):
        self.output_dir = output_dir
        self.video_path = video_path
        os.makedirs(output_dir, exist_ok=True)

    def frames_to_video(self, frame_rate=10):
        image_files = sorted(glob.glob(os.path.join(self.output_dir, "*.png")))
        if not image_files:
            raise FileNotFoundError("Нет кадров для сборки видео.")
        clip = ImageSequenceClip(image_files, fps=frame_rate)
        clip.write_videofile(self.video_path, codec="libx264")

    def save_frame(self, image: Image.Image, frame_num: int):
        path = os.path.join(self.output_dir, f"frame_{frame_num:04d}.png")
        image.save(path)
