import os
import torch
from PIL import Image
from diffusers import StableDiffusionPipeline, ControlNetModel, UniPCMultistepScheduler
from torchvision import transforms

class VisionModule:
    def __init__(self):
        sdxl_path = "models/stable-diffusion/sd_xl_base_1.0.safetensors"
        control_path = "models/controlnet/control_canny_sd15.safetensors"

        self.pipe = StableDiffusionPipeline.from_single_file(sdxl_path, torch_dtype=torch.float16).to("cuda")
        self.controlnet = ControlNetModel.from_single_file(control_path, torch_dtype=torch.float16).to("cuda")
        self.pipe.scheduler = UniPCMultistepScheduler.from_config(self.pipe.scheduler.config)

    def generate_image(self, prompt, height=512, width=512, guidance_scale=7.5, num_inference_steps=30):
        image = self.pipe(prompt=prompt,
                          height=height,
                          width=width,
                          guidance_scale=guidance_scale,
                          num_inference_steps=num_inference_steps).images[0]
        return image

    def save_image(self, image, path="output/generated_image.png"):
        os.makedirs(os.path.dirname(path), exist_ok=True)
        image.save(path)
