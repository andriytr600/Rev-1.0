import os
import torch
from TTS.api import TTS

class AudioModule:
    def __init__(self, output_dir="output/audio", voice="default"):
        self.output_dir = output_dir
        os.makedirs(output_dir, exist_ok=True)
        self.voice = voice
        self.tts = TTS(model_name="tts_models/multilingual/multi-dataset/your_tts", progress_bar=False, gpu=True)

    def generate_audio(self, text, filename="speech.wav"):
        path = os.path.join(self.output_dir, filename)
        self.tts.tts_to_file(text=text, speaker=self.voice, file_path=path)
        return path
