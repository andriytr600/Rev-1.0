from llm import LocalLLM
from telegram_bot import run_telegram_bot
from webui import start_webui

if __name__ == "__main__":
    llm = LocalLLM(model_path="models/llm")
    run_telegram_bot(llm)
    start_webui(llm)
