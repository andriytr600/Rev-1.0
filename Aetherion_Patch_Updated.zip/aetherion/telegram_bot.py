from telegram import Update, Bot
from telegram.ext import ApplicationBuilder, CommandHandler, MessageHandler, filters, ContextTypes
import os
from dotenv import load_dotenv

load_dotenv()
TOKEN = os.getenv("TELEGRAM_BOT_TOKEN")
ADMIN_ID = int(os.getenv("ADMIN_ID", "0"))

def build_prompt(user_text):
    return f"Пользователь спросил: {user_text}\nОтвет:"

async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_message = update.message.text
    response = context.bot_data["llm"].generate(build_prompt(user_message))
    await update.message.reply_text(response)

async def start_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("Привет! Я локальный ИИ, задай мне любой вопрос.")

def run_telegram_bot(llm_instance):
    app = ApplicationBuilder().token(TOKEN).build()
    app.bot_data["llm"] = llm_instance
    app.add_handler(CommandHandler("start", start_command))
    app.add_handler(MessageHandler(filters.TEXT & (~filters.COMMAND), handle_message))
    app.run_polling()
