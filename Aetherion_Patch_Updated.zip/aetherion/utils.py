import os
import importlib.util
import shutil

def check_dependencies(packages):
    missing = []
    for package in packages:
        if importlib.util.find_spec(package) is None:
            missing.append(package)
    return missing

def ensure_directories(paths):
    for path in paths:
        os.makedirs(path, exist_ok=True)

def clear_output_folder(folder="output"):
    if os.path.exists(folder):
        shutil.rmtree(folder)
        os.makedirs(folder, exist_ok=True)

def log_event(message, logfile="output/log.txt"):
    os.makedirs(os.path.dirname(logfile), exist_ok=True)
    with open(logfile, "a") as f:
        f.write(message + "\n")
