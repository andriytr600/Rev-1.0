import gradio as gr

def start_webui(llm):
    def respond_to_user(input_text):
        return llm.generate(input_text)

    with gr.Blocks() as demo:
        gr.Markdown("### Aetherion RTX: Локальный ИИ чат")
        chatbot = gr.Chatbot()
        with gr.Row():
            user_input = gr.Textbox(show_label=False, placeholder="Введите сообщение...", scale=8)
            send_btn = gr.Button("Отправить", scale=1)

        def respond(user_text, chat_history):
            response = llm.generate(user_text)
            chat_history.append((user_text, response))
            return "", chat_history

        send_btn.click(respond, [user_input, chatbot], [user_input, chatbot])
        user_input.submit(respond, [user_input, chatbot], [user_input, chatbot])

    demo.launch(server_name="0.0.0.0", server_port=7860, share=True)
