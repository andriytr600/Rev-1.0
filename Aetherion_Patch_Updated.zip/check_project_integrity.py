import os
from utils import check_dependencies

required_dirs = [
    "models/llm",
    "models/stable-diffusion",
    "models/controlnet",
    "models/tortoise/voices",
    "output/audio",
    "output/video_frames"
]

required_files = [
    "aetherion/main.py",
    "aetherion/llm.py",
    "aetherion/telegram_bot.py",
    "aetherion/webui.py",
    "aetherion/vision.py",
    "aetherion/video.py",
    "aetherion/audio.py",
    "aetherion/utils.py",
    "models/whisper/model.bin",
]

print("[*] Проверка директорий...")
missing_dirs = [d for d in required_dirs if not os.path.isdir(d)]
if missing_dirs:
    print("[!] Отсутствуют директории:")
    for d in missing_dirs:
        print("   -", d)
else:
    print("    Все директории присутствуют.")

print("\n[*] Проверка файлов...")
missing_files = [f for f in required_files if not os.path.isfile(f)]
if missing_files:
    print("[!] Отсутствуют файлы:")
    for f in missing_files:
        print("   -", f)
else:
    print("    Все необходимые файлы присутствуют.")

print("\n[*] Проверка Python-зависимостей...")
missing_deps = check_dependencies([
    "transformers", "torch", "diffusers", "gradio", "telegram", "dotenv", "moviepy", "TTS"
])
if missing_deps:
    print("[!] Отсутствующие библиотеки:")
    for pkg in missing_deps:
        print("   -", pkg)
else:
    print("    Все библиотеки установлены.")

print("\n[✓] Проверка завершена.")
