import os

def download_model(url, target_path):
    if not os.path.exists(target_path):
        os.makedirs(os.path.dirname(target_path), exist_ok=True)
        print(f"Скачиваю: {url}")
        os.system(f"wget -c -O {target_path} {url}")
    else:
        print(f"Уже загружено: {target_path}")

def main():
    print("Загрузка моделей Aetherion...")

    models = [
        # Stable Diffusion v1.5
        {
            "url": "https://huggingface.co/runwayml/stable-diffusion-v1-5/resolve/main/v1-5-pruned-emaonly.safetensors",
            "path": "models/stable-diffusion/v1-5-pruned-emaonly.safetensors"
        },

        # Stable Diffusion XL (Base)
        {
            "url": "https://huggingface.co/stabilityai/stable-diffusion-xl-base-1.0/resolve/main/sd_xl_base_1.0.safetensors",
            "path": "models/stable-diffusion/sd_xl_base_1.0.safetensors"
        },

        # Stable Diffusion XL (Refiner)
        {
            "url": "https://huggingface.co/stabilityai/stable-diffusion-xl-refiner-1.0/resolve/main/sd_xl_refiner_1.0.safetensors",
            "path": "models/stable-diffusion/sd_xl_refiner_1.0.safetensors"
        },

        # ControlNet: Canny
        {
            "url": "https://huggingface.co/lllyasviel/ControlNet/resolve/main/models/control_canny_sd15.safetensors",
            "path": "models/controlnet/control_canny_sd15.safetensors"
        },

        # ControlNet: Depth
        {
            "url": "https://huggingface.co/lllyasviel/ControlNet/resolve/main/models/control_depth_sd15.safetensors",
            "path": "models/controlnet/control_depth_sd15.safetensors"
        },

        # ControlNet: OpenPose
        {
            "url": "https://huggingface.co/lllyasviel/ControlNet/resolve/main/models/control_openpose_sd15.safetensors",
            "path": "models/controlnet/control_openpose_sd15.safetensors"
        },

        # Whisper large-v2
        {
            "url": "https://huggingface.co/openai/whisper/resolve/main/large-v2.pt",
            "path": "models/whisper/large-v2.pt"
        },

        # Bark TTS model (пример)
        {
            "url": "https://huggingface.co/suno/bark/resolve/main/bark_small.pt",
            "path": "models/bark/bark_small.pt"
        },

        # AnimateDiff motion module (пример)
        {
            "url": "https://huggingface.co/guoyww/animatediff/resolve/main/mm_sd_v14.ckpt",
            "path": "models/animatediff/mm_sd_v14.ckpt"
        },

        # Tortoise TTS - autoregressive model
        {
            "url": "https://huggingface.co/erogol/tortoise-tts/resolve/main/models/autoregressive.pth",
            "path": "models/tortoise/autoregressive.pth"
        },

        # Tortoise TTS - vocoder
        {
            "url": "https://huggingface.co/erogol/tortoise-tts/resolve/main/models/vocoder.pth",
            "path": "models/tortoise/vocoder.pth"
        },

        # Tortoise TTS - voices presets
        {
            "url": "https://huggingface.co/erogol/tortoise-tts/resolve/main/models/voices.tar.gz",
            "path": "models/tortoise/voices.tar.gz"
        }
    ]

    for model in models:
        download_model(model["url"], model["path"])

if __name__ == "__main__":
    main()
