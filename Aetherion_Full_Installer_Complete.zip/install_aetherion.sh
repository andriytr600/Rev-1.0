#!/bin/bash
echo "Установка Aetherion..."
sudo apt update && sudo apt install -y python3 python3-venv python3-pip git wget ffmpeg curl

python3 -m venv venv
source venv/bin/activate

pip install --upgrade pip
pip install -r requirements.txt

mkdir -p models/llm models/stable-diffusion models/controlnet output

echo "Установка завершена. Запуск..."
python3 aetherion/main.py
