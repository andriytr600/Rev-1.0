import gradio as gr
from aetherion.llm import LocalLLM

llm = LocalLLM("models/llm")

def chat(prompt):
    return llm.generate(prompt)

def launch_webui():
    iface = gr.Interface(fn=chat, inputs="text", outputs="text", title="Aetherion Chat")
    iface.launch(share=os.getenv("USE_NGROK", "false").lower() == "true")
