import os
from dotenv import load_dotenv
from aetherion.telegram_bot import run_telegram_bot
from aetherion.webui import launch_webui

def main():
    load_dotenv()
    print("Запуск Aetherion...")

    # Параллельный запуск бота и WebUI
    from threading import Thread
    Thread(target=run_telegram_bot).start()
    Thread(target=launch_webui).start()

if __name__ == "__main__":
    main()
