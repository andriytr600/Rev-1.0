import os
import torch
import torchaudio
import whisper
from bark import generate_audio, preload_models
from scipy.io.wavfile import write as write_wav

class AudioModule:
    def __init__(self):
        self.whisper_model = whisper.load_model("large")
        preload_models()

    def transcribe(self, filepath):
        result = self.whisper_model.transcribe(filepath)
        return result["text"]

    def synthesize(self, text, output_path="output/voice.wav"):
        audio_array = generate_audio(text)
        os.makedirs(os.path.dirname(output_path), exist_ok=True)
        write_wav(output_path, rate=24000, data=audio_array)
        return output_path
