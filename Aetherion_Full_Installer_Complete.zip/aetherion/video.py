import os
import subprocess

def generate_video_with_anim_diff(prompt):
    # Здесь будет команда запуска AnimateDiff
    # Предположим, что установлен отдельный скрипт anim_diff.py
    output_path = "output/generated_video.mp4"
    os.makedirs("output", exist_ok=True)
    subprocess.call(["python3", "scripts/anim_diff.py", "--prompt", prompt, "--out", output_path])
    return output_path

def generate_video_with_videocrafter(prompt):
    # Заглушка: предположим, VideoCrafter вызовется отдельно
    output_path = "output/videocrafter_output.mp4"
    subprocess.call(["python3", "scripts/videocrafter_gen.py", "--text", prompt, "--output", output_path])
    return output_path
