import os
from dotenv import load_dotenv

def load_config():
    load_dotenv()
    return {
        "telegram_token": os.getenv("TELEGRAM_BOT_TOKEN"),
        "language": os.getenv("LANGUAGE", "ru"),
        "use_ngrok": os.getenv("USE_NGROK", "false").lower() == "true",
        "nsfw_mode": os.getenv("NSFW_MODE", "false").lower() == "true",
    }

def ensure_directories():
    for d in ["output", "models/llm", "models/stable-diffusion", "models/controlnet"]:
        os.makedirs(d, exist_ok=True)
