import torch
from diffusers import StableDiffusionPipeline, ControlNetModel, UniPCMultistepScheduler
from PIL import Image
import os

class VisionModule:
    def __init__(self, model_path='models/stable-diffusion', controlnet_path=None):
        self.pipe = StableDiffusionPipeline.from_pretrained(
            model_path,
            torch_dtype=torch.float16
        ).to("cuda")
        self.pipe.scheduler = UniPCMultistepScheduler.from_config(self.pipe.scheduler.config)

        if controlnet_path:
            controlnet = ControlNetModel.from_pretrained(controlnet_path, torch_dtype=torch.float16).to("cuda")
            self.pipe.controlnet = controlnet

    def generate_image(self, prompt, negative_prompt="", steps=30, guidance=7.5, height=512, width=512):
        result = self.pipe(
            prompt=prompt,
            negative_prompt=negative_prompt,
            num_inference_steps=steps,
            guidance_scale=guidance,
            height=height,
            width=width
        )
        image: Image = result.images[0]
        out_path = "output/generated_image.png"
        os.makedirs(os.path.dirname(out_path), exist_ok=True)
        image.save(out_path)
        return out_path
